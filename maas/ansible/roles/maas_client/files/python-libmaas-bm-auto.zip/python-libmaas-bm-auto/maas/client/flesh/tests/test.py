"""Tests for `maas.client.flesh`."""

__all__ = []
